package com.cts.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.model.Company;


@Repository
public interface CompanyDao extends JpaRepository<Company, Integer> {

	void save(List<Company> company);
	
	public Company findCompanybyCompanyName(String name);

}

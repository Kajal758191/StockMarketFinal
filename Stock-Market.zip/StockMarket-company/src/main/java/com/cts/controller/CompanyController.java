package com.cts.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.dao.CompanyDao;
import com.cts.model.Company;

@RestController
@RequestMapping("/")

public class CompanyController {
	@Autowired
	private CompanyDao companyDao;
	
	@PostMapping("/add")
	public String addCompany(@RequestBody Company company) {
		companyDao.save(company);
		return "company added";
		
	}
	@GetMapping("/get")
	public List<Company> getCompany(){
		return (List<Company>) companyDao.findAll();
	}
	@GetMapping("/get/{id}")
	public Object findById(@PathVariable int id) {
		return companyDao.findById(id);
		
	}
	@PostMapping("/get/{companyname}/{newceo}")
	public void updateDetails(@PathVariable ("companyname") String companyName,
			@PathVariable("newceo") String ceo) {
		
		Company company=companyDao.findCompanybyCompanyName(companyName);
		company.setCeo(ceo);
		 companyDao.save(company);
		
	}
	
	

}

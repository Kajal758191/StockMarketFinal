package com.cts.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.NamedQuery;

import org.hibernate.annotations.DynamicUpdate;

@Entity
@Table(name = "Company")
@DynamicUpdate
@NamedQuery(name="Company.findCompanybyCompanyName", query="SELECT c FROM Company c where companyName=:name ") 
public class Company   {

	@GeneratedValue
	@Id
	@Column(name = "id")
	int Id;

	@Column(name = "companyName")
	String companyName;
	@Column(name = "turnover")
	Double turnover;
	@Column(name = "ceo")
	String ceo;
	@Column(name = "boardOfDirectors")
	String boardOfDirectors;
	@Column(name = "listedInStockExchange")
	String listedInStockExchange;

	@Column(name = "sectors")
	String sectors;

	@Column(name = "writeUp")
	String writeup;

	@Column(name = "stockCode")
	int stockCode;

	public void setTurnover(Double turnover) {
		this.turnover = turnover;
	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public Double getTurnover() {
		return turnover;
	}

	public void setTurnover(int i) {
		this.turnover = (double) i;
	}

	public String getCeo() {
		return ceo;
	}

	public void setCeo(String ceo) {
		this.ceo = ceo;
	}

	public String getBoardOfDirectors() {
		return boardOfDirectors;
	}

	public void setBoardOfDirectors(String boardOfDirectors) {
		this.boardOfDirectors = boardOfDirectors;
	}

	public String getListedInStockExchange() {
		return listedInStockExchange;
	}

	public void setListedInStockExchange(String listedInStockExchange) {
		this.listedInStockExchange = listedInStockExchange;
	}

	public String getSectors() {
		return sectors;
	}

	public void setSectors(String sectors) {
		this.sectors = sectors;
	}

	public String getWriteup() {
		return writeup;
	}

	public void setBriefWriteup(String writeup) {
		this.writeup = writeup;
	}

	public int getStockCode() {
		return stockCode;
	}

	public void setStockCode(int stockCode) {
		this.stockCode = stockCode;
	}

	public Company(int id, String companyName, Double turnover, String ceo, String boardOfDirectors,
			String listedInStockExchange, String sectors, String briefWriteup, int stockCode) {
		super();
		Id = id;
		this.companyName = companyName;
		this.turnover = turnover;
		this.ceo = ceo;
		this.boardOfDirectors = boardOfDirectors;
		this.listedInStockExchange = listedInStockExchange;
		this.sectors = sectors;
		this.writeup = briefWriteup;
		this.stockCode = stockCode;
	}

	public Company() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Company [Id=" + Id + ", companyName=" + companyName + ", turnover=" + turnover + ", ceo=" + ceo
				+ ", boardOfDirectors=" + boardOfDirectors + ", listedInStockExchange=" + listedInStockExchange
				+ ", sectors=" + sectors + ", briefWriteup=" + writeup + ", stockCode=" + stockCode + "]";
	}

}
